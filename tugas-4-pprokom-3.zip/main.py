str = "Py'thon"
str
str2 = 'Py"thon'
str2
"\"OK, \" sampai ketemu lagi."
teks = "Python adalah bahasa pemrograman yang powerfull.\nTerbukti Python bisa dijalankan di segala platform OS.\nJadi, saatnya kita menggunakan Python sebagai bahasa permrograman \nsehari-hari. Salam Python Dahsyat!"
print(teks)
kata = """Python adalah bahasa pemrograman yang powerfull.
Terbukti Python bisa dijalankan di segala platform OS.
Jadi, saatnya kita menggunakan Python sebagai bahasa pemrograman
sehari-hari. Salam Python Dahsyat!"""
print(kata)