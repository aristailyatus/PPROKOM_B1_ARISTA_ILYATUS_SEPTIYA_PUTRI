NIM = "23/518369/SV/22973"
NIM = NIM.replace("/", "")
print(NIM)